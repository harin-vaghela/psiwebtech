<!-- span_12 -->   			                            
<section class="primary row span_12 about-content grey_line">				                                    
  <article class="col span_4">
    <h2 class="block  black_line">About Us</h2> 
    <p class="home_block_text">At <strong>PSI WEB TECH</strong>, our success is based on our ability to create win-win relationships with our customers. We take great pride in everything we do, and invite you to pick up the phone and speak to anyone, at any time, about any part of your business.</p>				            
    <a class="block_link" href="article.php?page=about">> Read More</a>
  </article>                                   
  <article class="col span_4">
    <h2 class="block  black_line">What We Do</h2> 
    <p class="home_block_text">With our vast experience and technical know-how we can make sure that you get the most out of your IT systems. We offer a wide range of sevices including Strategic Consultancy, Technical Consultancy and Project Support.<br><br></p>				            
    <a class="block_link" href="article.php?page=services">> Our Services</a>			            
  </article>                                   
  <article class="col span_4">
    <h2 class="block  black_line">Get In Touch</h2> 
    <p class="home_block_text">If you'd like to discuss yor specific requirements with us we'd love to hear from you. <br><br><br><br><br></p>				            
    <a class="block_link" href="article.php?page=contact">> Contact Us</a>		            
  </article>                      			              			              			                            
</section>   