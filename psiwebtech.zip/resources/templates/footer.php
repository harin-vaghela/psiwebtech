  <!--  <footer id="grey_bar">        
        <div class="container">
          <p class="bottom_text">&copy; PSI Web Tech Ltd. All Rights Reserved.</p>
        </div>
    </footer>	  
      -->
    
      <footer id="grey_bar" class="row span_12">				                                    
        <div class="container">
        <!-- Utility Links -->  
        <div class="col span_6">
          <p class="bottom_text left_align"><a href="article.php?page=contact">Contact Us</a> | <a href="utility.php?page=privacy">Privacy</a> | <a href="utility.php?page=terms">Terms and Conditions</a></p>  
        </div>
        <div class="col span_6">
          <p class="bottom_text right_align">&copy; PSI Web Tech Ltd. All Rights Reserved.</p>  
        </div>
        </div>
      </footer>	