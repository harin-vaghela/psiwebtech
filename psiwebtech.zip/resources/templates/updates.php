      <section id="updates" class="row span_12">				                                    
        <article class="col span_8">	
          <h3 class="block">Updates</h3> 
          <p class="block_text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet consectetur est. Integer et enim ac magna porta dapibus. Quisque augue nulla, vestibulum id fermentum sed. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet consectetur est. Integer et enim ac magna porta dapibus. Quisque augue nulla, vestibulum id fermentum sed</p>          
        </article>                                   
        <article class="col span_4">
          <h3 class="block">Connect with Us</h3> 	
           <p class="block_text">Lorem ipsum dolor sit amet</p>		            
        </article>                                                                               			              			              			                            
      </section>   