      <!-- nav --> 
      <div class="row span_12 grey_line">	   				                                    					                                            
        <ul class="navigation fl_right">                                   
          <li class="nav_item<?php if($_SERVER["REQUEST_URI"] == '/'): ?> selected<?php endif ?>"><a href="/">Home</a></li>					                                                        
          <li class="nav_item<?php if($_SERVER["REQUEST_URI"] == '/article.php?page=about'): ?> selected<?php endif ?>"><a href="article.php?page=about">About Us</a></li>			
          <li class="nav_item<?php if($_SERVER["REQUEST_URI"] == '/article.php?page=services'): ?> selected<?php endif ?>"><a href="article.php?page=services">Services</a></li>
          <li class="nav_item<?php if($_SERVER["REQUEST_URI"] == '/article.php?page=careers'): ?> selected<?php endif ?>"><a href="article.php?page=careers">Work For Us</a></li>          		
          <li class="nav_item<?php if($_SERVER["REQUEST_URI"] == '/article.php?page=contact'): ?> selected<?php endif ?>"><a href="article.php?page=contact">Contact Us</a></li>			                        	                                           
        </ul>	
      </div>	
