  <!-- span_12 -->   			                            
  <section class="primary row span_12 about-content grey_line">				                                    
    <article class="col span_8">
      <h2 class="block  black_line">Contact Us</h2>           
      <p class="article_block_text">If you would like more information about any of the products and services that we offer, please contact us by using any of the following methods:
        <h3>Email</h3>
        <p class="article_block_text">
        You can email us at <a href="mailto:info@psiwebtech.com?Subject=Web%20Contact">info@psiwebtech.com</a> and we'll do our best to get back to you as soon as we can.
        </p>
        <h3>Telephone</h3>
        <p class="article_block_text">
        Alternatively, pick up the phone and give us a call on 020 8707 8888. 
        </p>
      </p>               				            
    </article>      
    <article class="col span_4">
      <h2 class="block  black_line">About Us</h2> 
      <p class="block_text">At <strong>PSI WEB TECH</strong>, our success is based on our ability to create win-win relationships with our customers. We take great pride in everything we do, and invite you to pick up the phone and speak to anyone, at any time, about any part of your business.</p>				            
      <a class="block_link" href="">> Read More</a>
    </article>                                                      			              			              			                            
  </section>   