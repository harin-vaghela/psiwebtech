<h2 class="block">Services</h2> 	  
      <!-- span_12 -->  
<section id="promos" class="row span_12">	        		                                    
  <article class="col span_3 content_block">	
    <a href="article.php?page=itinfrastructure"><img class="services-image"  src="assets/images/infrastructure.png" alt="" title="IT Infrastructure"/></a>            
  </article>                                   
  <article class="col span_3 content_block">
    <a href="article.php?page=remote-support"><img class="services-image"  src="assets/images/remote-support.png" alt="" title="Remote Monitoring and Support"/></a>			            
  </article>                                   
  <article class="col span_3 content_block">
    <a href="article.php?page=procurement"><img class="services-image"  src="assets/images/procurement.png" alt="" title="Procurement"/></a>		            
  </article>  
  <article class="col span_3 content_block">	 
    <a href="article.php?page=cloud-services"><img class="services-image" src="assets/images/cloud-services.png" alt="" title="Cloud Services"/></a>	           
  </article>                                                 			              			              			                            
</section>   