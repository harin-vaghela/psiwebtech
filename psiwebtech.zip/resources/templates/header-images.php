      <header class="row span_12 banner grey_line">		
            <div class="slider-wrapper theme-default">
            <div id="slider" class="nivoSlider">
                <a href=""><img src="assets/images/banner-v2.png" data-thumb="assets/images/banner.png" alt="" title="#htmlcaption1"/></a>
                <a href=""><img src="assets/images/banner-globe-v2.png" data-thumb="assets/images/banner-globe.png" alt="" title="#htmlcaption2" data-transition="slideInLeft"/></a>
            </div>
            <div id="htmlcaption1" class="nivo-html-caption">
                <p>We understand your business.</p> 
                <a class="fl_right" href="article.php?page=services">View Services ></a>                
            </div>
            <div id="htmlcaption2" class="nivo-html-caption">
                <p>We understand the global <br> needs of your business.</p>
                <a class="fl_right" href="article.php?page=services">View Services ></a>                
            </div>            
        </div>		                                                                             			                            
      </header>     